defmodule Card do
  @moduledoc """
  Documentation for `Card`.
  """

  @doc """
  Hello world.

  ## Examples

      iex> Card.hello()
      :world

  """
  def hello do
    :world
  end
end
