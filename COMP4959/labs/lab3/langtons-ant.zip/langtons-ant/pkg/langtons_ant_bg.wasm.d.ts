/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_ant_free: (a: number, b: number) => void;
export const ant_new: (a: number) => number;
export const ant_step: (a: number) => [number, number];
export const ant_x: (a: number) => number;
export const ant_y: (a: number) => number;
export const ant_direction: (a: number) => number;
export const __wbindgen_export_0: WebAssembly.Table;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_start: () => void;
