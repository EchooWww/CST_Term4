export const prompt = "How many buttons to create?";
export const button = "Go!";
export const success = "Excellent memory!";
export const failure = "Wrong order!";
export const invalidInput = "Please enter a number from 3 to 7";
