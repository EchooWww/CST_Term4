module.exports = {
  getDate: "Hello %1, What a beautiful day. Server current date and time is %2",
  fileNotFound: "The file %1 was not found",
  notFound: "404 Not Found",
  writeFailed: "Failed to write to file",
  writeSuccess: "Successfully wrote to file",
};
